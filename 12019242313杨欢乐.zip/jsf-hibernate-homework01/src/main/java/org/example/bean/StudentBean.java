package org.example.bean;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.example.dao.StudentDAO;
import org.example.dao.impl.StudentDAOImpl;
import org.example.entity.StudentEntity;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import java.util.ArrayList;
import java.util.List;

/**
 * @Author: HAPPY
 * @Project_name: JSF
 * @Package_name: org.example.pojo
 * @Date: 2021/9/27 21:53
 */


// 重命名解决和上一个模块的冲突问题，清缓存没用，那就只能换名字了 =_=!
// com.sun.faces.mgbean.BeanManager.addBean JSF1074：名为 'student' 的受管 bean 已注册。
// 将现有受管 bean 类类型 org.example.bean.StudentBean 替换为 org.example.pojo.Student。
@ManagedBean(name = "std")
@SessionScoped
@Data
@NoArgsConstructor
@AllArgsConstructor
public class StudentBean {
    private StudentEntity studentEntity = new StudentEntity();
    private List<StudentEntity> studentEntityList = new ArrayList<>();

    public String save() {
        StudentDAO studentDAO = new StudentDAOImpl();
        System.out.println(this.studentEntity);
        if(studentDAO.insetStudent(this.studentEntity)) {
            return "info";
        } else {
            return "register";
        }
    }

    public String login() {
        StudentDAO studentDAO = new StudentDAOImpl();

        this.studentEntity = studentDAO.login(this.studentEntity);

        if (this.studentEntity != null) {
            return "info";
        } else {
            return "login";
        }
    }

    public String clearValue() {
        // 重新new 一个对象，使其值都变为空，解决页面加载后有默认值的问题
        this.studentEntity = new StudentEntity();
        return "register";
    }

    public void selectAllStudents() {
        StudentDAO studentDAO = new StudentDAOImpl();
        this.studentEntityList = studentDAO.queryAll();
    }

    // 初始化时加载
    @PostConstruct
    public void init() {
        this.studentEntity = new StudentEntity();
        selectAllStudents();
    }
}

create definer = root@localhost trigger insertUpdataRoutesPeople
    after insert
    on userorder
    for each row
begin
    UPDATE TouristRoutes SET TouristRoutes.nowPeople = TouristRoutes.nowPeople+1 
   where new.touristId=TouristRoutes.touristId ;
end;


create definer = root@localhost trigger deleteUpdataRoutesPeople
    after delete
    on userorder
    for each row
begin
    UPDATE TouristRoutes SET TouristRoutes.nowPeople = TouristRoutes.nowPeople-1 
   where old.touristId=TouristRoutes.touristId ;
end;

